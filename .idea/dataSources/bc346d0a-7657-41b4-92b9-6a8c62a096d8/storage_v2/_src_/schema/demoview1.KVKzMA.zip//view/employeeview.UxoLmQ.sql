create definer = root@localhost view employeeview as
select `demoview1`.`employees`.`employeeID` AS `employeeID`, `demoview1`.`employees`.`employeeName` AS `employeeName`
from `demoview1`.`employees`;

