create
    definer = root@localhost procedure delete_class_by_id(IN classIdIn int)
begin
    UPDATE students set `classId` = null where `classId` = `classIdIn`;
    DELETE FROM classes WHERE id = classIdIn;
end;

