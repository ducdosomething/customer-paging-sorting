create definer = root@localhost view customers_view as
select `demoview1`.`customers`.`customerName` AS `customerName`, `demoview1`.`customers`.`age` AS `age`
from `demoview1`.`customers`
where (`demoview1`.`customers`.`age` is not null);

