create definer = root@localhost view employeedepartmentview as
select `e`.`employeeID`     AS `employeeID`,
       `e`.`employeeName`   AS `employeeName`,
       `e`.`departmentID`   AS `departmentID`,
       `d`.`departmentName` AS `departmentName`
from (`demoview1`.`employees` `e` join `demoview1`.`departments` `d` on ((`e`.`departmentID` = `d`.`departmentID`)));

