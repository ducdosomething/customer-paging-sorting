create definer = root@localhost view view_stp as
select `s`.`id` AS `id`, `s`.`FullName` AS `fullname`, `s`.`Age` AS `age`, `p`.`point` AS `point`
from (`quanlyhocvien`.`students` `s` join `quanlyhocvien`.`point` `p` on ((`p`.`student_id` = `s`.`id`)));

