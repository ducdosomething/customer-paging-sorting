create definer = root@localhost view view2 as
select `quanlyhocvien`.`students`.`id`       AS `id`,
       `quanlyhocvien`.`students`.`FullName` AS `fullname`,
       `quanlyhocvien`.`students`.`Age`      AS `age`,
       `quanlyhocvien`.`students`.`Phone`    AS `Phone`
from `quanlyhocvien`.`students`
where (`quanlyhocvien`.`students`.`Age` is not null);

