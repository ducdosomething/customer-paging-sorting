create definer = root@localhost view vw_ctpnhap as
select `p`.`so_phieu_nhap`                            AS `SốPhiếuNhậpHàng`,
       `ctn`.`vat_tu_id`                              AS `MãVậtTư`,
       `ctn`.`so_luong_nhap`                          AS `SốLượngNhập`,
       `ctn`.`don_gia_nhap`                           AS `ĐơnGiáNhập`,
       (`ctn`.`so_luong_nhap` * `ctn`.`don_gia_nhap`) AS `ThànhTiền`
from (`quanlyvattu`.`phieunhap` `p` join `quanlyvattu`.`ct_phieunhap` `ctn` on ((`p`.`id` = `ctn`.`phieu_nhap_id`)));

