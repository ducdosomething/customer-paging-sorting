create definer = root@localhost view vw_ctpnhap_vt_pn as
select `pn`.`so_phieu_nhap`                           AS `SốPhiếuNhậpHàng`,
       `pn`.`ngay_nhap`                               AS `NgayNhap`,
       count(distinct `ctddh`.`don_dat_hang_id`)      AS `SoDonDatHang`,
       `vt`.`ma_vat_tu`                               AS `MãVậtTư`,
       `vt`.`ten_vat_tu`                              AS `TênVậtTư`,
       `ctn`.`so_luong_nhap`                          AS `SoLuongNhap`,
       (`ctn`.`so_luong_nhap` * `ctn`.`don_gia_nhap`) AS `ThànhTiền`
from ((((`quanlyvattu`.`ct_phieunhap` `ctn` join `quanlyvattu`.`vattu` `vt`
         on ((`ctn`.`phieu_nhap_id` = `vt`.`id`))) join `quanlyvattu`.`phieunhap` `pn`
        on ((`ctn`.`phieu_nhap_id` = `pn`.`id`))) join `quanlyvattu`.`dondathang` `ddh`
       on ((`pn`.`don_dat_hang_id` = `ddh`.`id`))) join `quanlyvattu`.`ct_dondathang` `ctddh`
      on ((`pn`.`don_dat_hang_id` = `ctddh`.`don_dat_hang_id`)))
group by `pn`.`so_phieu_nhap`, `pn`.`ngay_nhap`, `ctn`.`vat_tu_id`, `ctn`.`so_luong_nhap`, `ctn`.`don_gia_nhap`,
         `vt`.`ten_vat_tu`;

